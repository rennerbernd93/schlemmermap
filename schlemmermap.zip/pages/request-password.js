export default function RequestPasswordPage() {
  return (
    <div style={{ padding: "40px", fontFamily: "sans-serif" }}>
      <h1>Passwort anfordern</h1>
      <p>Diese Seite ist aktuell leer, wird aber benötigt, damit Next.js builden kann.</p>
    </div>
  );
}
