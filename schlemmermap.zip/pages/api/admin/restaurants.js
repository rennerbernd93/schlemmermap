import prisma from "../../../lib/prisma";

export default async function handler(req, res) {
  const admin = req.cookies.admin;
  if (!admin) return res.status(401).json({ error: "Unauthorized" });

  const restaurants = await prisma.restaurant.findMany({
    orderBy: { id: "desc" }
  });

  res.json(restaurants);
}
