import dynamic from "next/dynamic";

const MapPage = dynamic(() => import("../components/MapPage"), {
  ssr: false,
});

export default function Home() {
  return (
    <div style={{ maxWidth: 1000, margin: "0 auto", padding: 16 }}>
      <MapPage />
    </div>
  );
}
