import { useState } from "react";
import dynamic from "next/dynamic";

const MapAdd = dynamic(() => import("../components/MapAdd"), { ssr: false });

export default function AddMenuMap() {
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState(null);

  function handleUserClick(data) {
    // data: { mode, lat, lng, name, website, phone, menuUrl, existing?, googleData }
    setFormData(data);
    setShowModal(true);
  }

  if (!formData) return (
    <div style={{ maxWidth: 1000, margin: "0 auto", padding: 16 }}>
      <div style={{ textAlign: "center", marginTop: 20 }}>
        <img src="/logo.png" style={{ width: 180 }} />
      </div>
      <MapAdd onUserClick={handleUserClick} />
    </div>
  );

  const {
    mode,
    existing,
    lat,
    lng,
    name,
    website,
    phone,
    menuUrl,
    googleData
  } = formData;

  const isEdit = mode === "edit";

  const submitUrl = isEdit
    ? "/api/restaurants/update"
    : "/api/restaurants/add";

  return (
    <div style={{ maxWidth: 1000, margin: "0 auto", padding: 16 }}>
      
      {/* LOGO */}
      <div style={{ textAlign: "center", marginTop: 20, marginBottom: 20 }}>
        <img src="/logo.png" alt="Logo" style={{ width: 180 }} />
      </div>

      <h2 style={{ textAlign: "center" }}>
        {isEdit ? "Restaurant bearbeiten" : "Neues Restaurant hinzufügen"}
      </h2>

      <p style={{ textAlign: "center" }}>
        Klicke auf die Karte, um einen Standort auszuwählen oder ein bestehendes Restaurant zu bearbeiten.
      </p>

      <MapAdd onUserClick={handleUserClick} />

      {/* -------- MODAL -------- */}
      {showModal && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            background: "rgba(0,0,0,0.5)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 99999,
          }}
        >
          <div
            style={{
              background: "#fff",
              width: "95%",
              maxWidth: 700,
              maxHeight: "90%",
              overflowY: "auto",
              borderRadius: 10,
              padding: 20,
              display: "flex",
              flexDirection: "column",
              gap: 20,
            }}
          >

            {/* HEADLINE */}
            <h2 style={{ marginTop: 0 }}>
              {isEdit ? "Bestehendes Restaurant bearbeiten" : "Neuen Eintrag anlegen"}
            </h2>

            {/* LOCATION INFO */}
            <p>
              Standort:<br />
              <b>{lat.toFixed(5)}, {lng.toFixed(5)}</b>
            </p>

            {/* LAYOUT: Links = Eingabeform, Rechts = Google-Daten */}
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: 20,
              }}
            >
              {/* ------- FORM COLUMN ------- */}
              <div>
                <h3>Daten speichern</h3>

                <form method="POST" action={submitUrl}>

                  {/* ID nur bei EDIT */}
                  {isEdit && (
                    <input type="hidden" name="id" value={existing.id} />
                  )}

                  <input type="hidden" name="latitude" value={lat} />
                  <input type="hidden" name="longitude" value={lng} />

                  <label style={{ display: "block", marginTop: 10 }}>
                    Restaurantname
                  </label>
                  <input
                    name="name"
                    required
                    defaultValue={name}
                    style={{ width: "100%", padding: 8 }}
                  />

                  <label style={{ display: "block", marginTop: 10 }}>
                    Website
                  </label>
                  <input
                    name="website"
                    defaultValue={website}
                    style={{ width: "100%", padding: 8 }}
                  />

                  <label style={{ display: "block", marginTop: 10 }}>
                    Telefon
                  </label>
                  <input
                    name="phone"
                    defaultValue={phone}
                    style={{ width: "100%", padding: 8 }}
                  />

                  <label style={{ display: "block", marginTop: 10 }}>
                    Speisekarte URL
                  </label>
                  <input
                    name="menuUrl"
                    defaultValue={menuUrl}
                    style={{ width: "100%", padding: 8 }}
                  />

                  <button
                    type="submit"
                    style={{
                      marginTop: 20,
                      width: "100%",
                      padding: 12,
                      background: "black",
                      color: "white",
                      borderRadius: 6,
                    }}
                  >
                    {isEdit ? "Eintrag aktualisieren" : "Restaurant speichern"}
                  </button>
                </form>
              </div>

              {/* ------- GOOGLE INFO COLUMN ------- */}
              <div>
                <h3>Google-Daten (nur Anzeige)</h3>

                {googleData.address && (
                  <p>
                    <b>Adresse:</b><br />
                    {googleData.address}
                  </p>
                )}

                {googleData.category && (
                  <p><b>Kategorie:</b> {googleData.category}</p>
                )}

                {googleData.rating && (
                  <p><b>Bewertung:</b> ⭐ {googleData.rating}</p>
                )}

                {googleData.phone && (
                  <p><b>Telefon:</b> {googleData.phone}</p>
                )}

                {googleData.openingHours?.length > 0 && (
                  <div>
                    <b>Öffnungszeiten:</b>
                    <ul>
                      {googleData.openingHours.map((h, i) => (
                        <li key={i}>{h}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {googleData.photos?.length > 0 && (
                  <div>
                    <b>Fotos:</b>
                    <div style={{
                      display: "flex",
                      overflowX: "auto",
                      gap: 10,
                      marginTop: 5
                    }}>
                      {googleData.photos.map((src, i) => (
                        <img
                          key={i}
                          src={src}
                          style={{
                            width: 120,
                            height: 90,
                            objectFit: "cover",
                            borderRadius: 6,
                          }}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* CLOSE BUTTON */}
            <button
              onClick={() => setShowModal(false)}
              style={{
                width: "100%",
                padding: 12,
                borderRadius: 6,
                background: "#ddd",
              }}
            >
              Abbrechen
            </button>

          </div>
        </div>
      )}

    </div>
  );
}
