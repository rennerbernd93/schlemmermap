"use client";
import { useEffect, useRef, useState } from "react";

export default function MapPage() {
  const mapRef = useRef(null);
  const autocompleteRef = useRef(null);
  const markerRef = useRef(null);
  const userMarkerRef = useRef(null);

  const [googleLoaded, setGoogleLoaded] = useState(false);
  const [map, setMap] = useState(null);
  const [mode, setMode] = useState("search"); // search | add
  const [restaurants, setRestaurants] = useState([]);

  //-----------------------------------------------------
  // 1) GOOGLE MAPS LADEN — EINMAL PRO SEITE
  //-----------------------------------------------------
  useEffect(() => {
    if (window.google) {
      setGoogleLoaded(true);
      return;
    }

    const script = document.createElement("script");
    script.src =
      `https://maps.googleapis.com/maps/api/js?key=${process.env.NEXT_PUBLIC_MAPS_KEY}&libraries=places,marker&loading=async`;
    script.async = true;
    script.onload = () => setGoogleLoaded(true);

    document.head.appendChild(script);
  }, []);

  //-----------------------------------------------------
  // 2) MAP INITIALISIEREN
  //-----------------------------------------------------
  useEffect(() => {
    if (!googleLoaded || !mapRef.current) return;

    const g = window.google;

    const m = new g.maps.Map(mapRef.current, {
      center: { lat: 52.52, lng: 13.405 },
      zoom: 13,
      gestureHandling: "greedy",
      fullscreenControl: false,
      streetViewControl: false,
      mapTypeControl: false,
    });

    setMap(m);

    loadRestaurants(m);
  }, [googleLoaded]);

  //-----------------------------------------------------
  // 3) RESTAURANTS LADEN & MARKER SETZEN
  //-----------------------------------------------------
  async function loadRestaurants(m) {
    const res = await fetch("/api/restaurants/public").then((r) => r.json());
    setRestaurants(res);

    const g = window.google;

    res.forEach((r) => {
      new g.maps.Marker({
        position: { lat: r.latitude, lng: r.longitude },
        map: m,
        icon: {
          url: "https://maps.google.com/mapfiles/ms/icons/red-dot.png",
          scaledSize: new g.maps.Size(32, 32),
        },
      });
    });
  }

  //-----------------------------------------------------
  // 4) SUCHFELD (NEUE API: gmp-place-autocomplete)
  //-----------------------------------------------------
  useEffect(() => {
    if (!googleLoaded || !autocompleteRef.current || !map) return;

    const g = window.google;

    const autocomplete = new g.maps.places.PlaceAutocompleteElement();
    autocompleteRef.current.appendChild(autocomplete);

    autocomplete.addEventListener("gmp-placeselect", (e) => {
      const place = e.detail.place;

      if (!place?.location) return;

      map.setCenter(place.location);
      map.setZoom(15);
    });
  }, [googleLoaded, map]);

  //-----------------------------------------------------
  // 5) STANDORT-FINDER
  //-----------------------------------------------------
  function locateMe() {
    if (!navigator.geolocation || !map) return;

    navigator.geolocation.getCurrentPosition((pos) => {
      const loc = { lat: pos.coords.latitude, lng: pos.coords.longitude };

      map.setCenter(loc);
      map.setZoom(16);

      const g = window.google;

      if (userMarkerRef.current) userMarkerRef.current.setMap(null);

      userMarkerRef.current = new g.maps.Marker({
        position: loc,
        map,
        icon: {
          path: g.maps.SymbolPath.CIRCLE,
          scale: 10,
          fillColor: "#4285F4",
          fillOpacity: 1,
          strokeColor: "#fff",
          strokeWeight: 2,
        },
      });
    });
  }

  //-----------------------------------------------------
  // 6) ADD-MODUS: Marker setzen
  //-----------------------------------------------------
  useEffect(() => {
    if (!map || mode !== "add") return;

    const g = window.google;

    const clickListener = map.addListener("click", (e) => {
      const pos = e.latLng;

      if (markerRef.current) markerRef.current.setMap(null);

      markerRef.current = new g.maps.Marker({
        position: pos,
        map,
        draggable: true,
      });

      // später: Popup zum Speichern öffnen
      alert(`Neuer Standort gewählt:\nLat: ${pos.lat()}\nLng: ${pos.lng()}`);
    });

    return () => g.maps.event.removeListener(clickListener);
  }, [map, mode]);

  //-----------------------------------------------------
  // RENDER
  //-----------------------------------------------------
  return (
    <div style={{ position: "relative" }}>
      {/* LOGO */}
      <div style={{ textAlign: "center", marginBottom: 10 }}>
        <a href="/">
          <img
            src="/logo.png"
            alt="Logo"
            style={{ width: 160, cursor: "pointer" }}
          />
        </a>
      </div>

      {/* SUCHE */}
      <div
        ref={autocompleteRef}
        style={{
          position: "absolute",
          top: 15,
          left: 15,
          zIndex: 5,
          width: 260,
        }}
      ></div>

      {/* LOCATE BUTTON */}
      <div
        onClick={locateMe}
        style={{
          position: "absolute",
          bottom: 20,
          right: 20,
          zIndex: 5,
          width: 45,
          height: 45,
          borderRadius: "50%",
          background: "#fff",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          cursor: "pointer",
          fontSize: 22,
          boxShadow: "0 2px 6px rgba(0,0,0,0.3)",
        }}
      >
        📍
      </div>

      {/* MITTAGSTISCH HINZUFÜGEN */}
      <div
        onClick={() => setMode(mode === "search" ? "add" : "search")}
        style={{
          position: "absolute",
          bottom: 20,
          left: "50%",
          transform: "translateX(-50%)",
          zIndex: 5,
          padding: "12px 20px",
          background: mode === "add" ? "#ffd100" : "#fff",
          borderRadius: 30,
          fontWeight: "bold",
          cursor: "pointer",
          boxShadow: "0 2px 6px rgba(0,0,0,0.3)",
        }}
      >
        🍽️ Mittagstisch hinzufügen
      </div>

      {/* MAP */}
      <div
        ref={mapRef}
        style={{
          width: "100%",
          height: 500,
          borderRadius: 12,
          overflow: "hidden",
        }}
      ></div>
    </div>
  );
}
