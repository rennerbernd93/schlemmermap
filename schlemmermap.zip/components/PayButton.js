"use client";
import { PayPalButtons, PayPalScriptProvider } from "@paypal/react-paypal-js";

export default function PayButton({ duration, onSuccess }) {
  return (
    <PayPalScriptProvider
      options={{
        "client-id": process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID,
        currency: "EUR",
        components: "buttons",
      }}
    >
      <PayPalButtons
        style={{ layout: "vertical", color: "gold" }}
        createOrder={async () => {
          const res = await fetch("/api/paypal/create-order", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ duration }),
          });

          const data = await res.json();
          return data.id;
        }}
        onApprove={async (data) => {
          const res = await fetch("/api/paypal/capture-order", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ orderID: data.orderID }),
          });

          const capture = await res.json();
          onSuccess(capture);
        }}
      />
    </PayPalScriptProvider>
  );
}
